from odoo import models, fields, api

class CourseProgress(models.Model):
    _name = 'course.progress'
    _description = 'Course Progress'

    user_id = fields.Many2one('res.users', string="User", required=True)
    course_id = fields.Many2one('website.course', string="Course", required=True)
    progress = fields.Float(string="Progress", default=0.0)  # Percentage of completion
    completed = fields.Boolean(string="Completed", compute="_check_completion", store=True)

    @api.depends('progress')
    def _check_completion(self):
        for record in self:
            record.completed = record.progress >= 100
