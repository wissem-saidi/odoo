from odoo import models, fields

class WebsiteCourse(models.Model):
    _name = 'website.course'
    _description = 'Website Course'

    name = fields.Char(string="Course Name", required=True)
    description = fields.Text(string="Description")
    channel_id = fields.Many2one('mail.channel', string="Discussion Channel", ondelete="set null")

    def create_channel(self):
        for course in self:
            if not course.channel_id:
                course.channel_id = self.env['mail.channel'].create({
                    'name': f"Course: {course.name}",
                    'channel_type': 'channel',
                    'public': 'groups',
                })
