from odoo import models, fields

class CourseCertificate(models.Model):
    _name = 'course.certificate'
    _description = 'Course Certificate'

    user_id = fields.Many2one('res.users', string="User", required=True)
    course_id = fields.Many2one('website.course', string="Course", required=True)
    issue_date = fields.Date(string="Issue Date", default=fields.Date.context_today)
    certificate_url = fields.Char(string="Certificate URL")
