from odoo import http
from odoo.http import request

class WebsiteCourseController(http.Controller):

    @http.route('/course/progress/update', type='json', auth='user', website=True)
    def update_progress(self, course_id, progress):
        progress_record = request.env['course.progress'].search([
            ('user_id', '=', request.env.user.id),
            ('course_id', '=', course_id)
        ], limit=1)
        if not progress_record:
            progress_record = request.env['course.progress'].create({
                'user_id': request.env.user.id,
                'course_id': course_id,
                'progress': progress,
            })
        else:
            progress_record.progress = progress
        return {'status': 'success', 'completed': progress_record.completed}

    @http.route('/course/certificate/<int:course_id>', type='http', auth='user', website=True)
    def generate_certificate(self, course_id):
        user = request.env.user
        course = request.env['website.course'].browse(course_id)
        progress = request.env['course.progress'].search([
            ('user_id', '=', user.id),
            ('course_id', '=', course_id)
        ], limit=1)

        if progress and progress.completed:
            certificate = request.env['course.certificate'].create({
                'user_id': user.id,
                'course_id': course_id,
                'certificate_url': f'/certificates/{user.id}_{course_id}.pdf'
            })
            # PDF generation logic here
            return request.redirect(certificate.certificate_url)
        return request.redirect('/course/not-completed')

    @http.route('/sitemap.xml', type='http', auth='public', website=True)
    def sitemap(self):
        urls = request.env['website.course'].search([]).mapped(
            lambda course: f"/courses/{course.id}"
        )
        return request.render('website_kodekloud.sitemap', {'urls': urls})
