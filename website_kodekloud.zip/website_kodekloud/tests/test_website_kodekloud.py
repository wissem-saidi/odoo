from odoo.tests.common import TransactionCase

class TestWebsiteKodeKloud(TransactionCase):

    def setUp(self):
        super(TestWebsiteKodeKloud, self).setUp()
        self.course_model = self.env['website.course']
        self.progress_model = self.env['course.progress']
        self.user = self.env.ref('base.user_demo')

    def test_create_course(self):
        course = self.course_model.create({
            'name': 'Test Course',
            'description': 'A test course for automated testing.',
        })
        self.assertEqual(course.name, 'Test Course')

    def test_progress_update(self):
        course = self.course_model.create({
            'name': 'Test Course',
            'description': 'A test course for automated testing.',
        })
        progress = self.progress_model.create({
            'user_id': self.user.id,
            'course_id': course.id,
            'progress': 75.0,
        })
        self.assertEqual(progress.progress, 75.0)
        self.assertFalse(progress.completed)
