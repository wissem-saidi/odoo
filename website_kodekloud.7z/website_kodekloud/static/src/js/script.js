document.addEventListener("DOMContentLoaded", () => {
    console.log("KodeKloud website loaded!");

    // Smooth Scroll to Sections
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            const targetId = this.getAttribute("href");
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: "smooth" });
            }
        });
    });

    // Add hover effect to course cards
    const courseCards = document.querySelectorAll(".course-card");
    courseCards.forEach(card => {
        card.addEventListener("mouseenter", () => {
            card.style.boxShadow = "0 8px 16px rgba(0, 0, 0, 0.2)";
        });
        card.addEventListener("mouseleave", () => {
            card.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
        });
    });

    // Dynamic greeting based on time
    const heroHeader = document.querySelector(".hero h1");
    const hours = new Date().getHours();
    let greeting = "Welcome";
    if (hours < 12) {
        greeting = "Good Morning!";
    } else if (hours < 18) {
        greeting = "Good Afternoon!";
    } else {
        greeting = "Good Evening!";
    }
    heroHeader.textContent = `${greeting} Master DevOps, Cloud, and More`;
});
