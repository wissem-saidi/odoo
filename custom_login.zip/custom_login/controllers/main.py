# controllers/main.py
from odoo import http
from odoo.http import request

class CustomLoginController(http.Controller):

    @http.route('/web/login', type='http', auth='public', website=True)
    def login(self, **post):
        # You can add custom logic here, such as logging or modifying login behavior
        return request.render('custom_login_page.login_custom', {})
