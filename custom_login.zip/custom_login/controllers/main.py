# controllers/main.py
from odoo import http
from odoo.http import request
import json

class ModernWebsiteController(http.Controller):
    @http.route(['/modern_website/theme_config'], type='http', auth="user", website=True)
    def get_theme_config(self, **kwargs):
        """Endpoint to get theme configuration"""
        website = request.website
        theme_config = {
            'primary_color': website.sudo().get_theme_prime_color(),
            'secondary_color': website.sudo().get_theme_secondary_color(),
            'font_family': website.sudo().get_theme_font(),
        }
        return json.dumps(theme_config)

    @http.route(['/modern_website/update_theme'], type='json', auth="user", website=True)
    def update_theme(self, **kwargs):
        """Endpoint to update theme configuration"""
        if not request.env.user.has_group('website.group_website_designer'):
            return {'error': 'Access Denied'}

        website = request.website
        values = {}
        
        if kwargs.get('primary_color'):
            values['primary_color'] = kwargs['primary_color']
        if kwargs.get('secondary_color'):
            values['secondary_color'] = kwargs['secondary_color']
        if kwargs.get('font_family'):
            values['font_family'] = kwargs['font_family']

        try:
            website.sudo().write(values)
            return {'success': True}
        except Exception as e:
            return {'error': str(e)}

    @http.route(['/modern_website/sections'], type='http', auth="public", website=True)
    def get_custom_sections(self, **kwargs):
        """Endpoint to get custom section templates"""
        sections = request.env['modern.website.section'].sudo().search([])
        return request.render('modern_website.custom_sections', {
            'sections': sections
        })

    @http.route(['/modern_website/contact_form'], type='json', auth="public", website=True)
    def submit_contact_form(self, **kwargs):
        """Handle contact form submission"""
        try:
            # Create a lead/contact based on form data
            vals = {
                'name': kwargs.get('name'),
                'email_from': kwargs.get('email'),
                'phone': kwargs.get('phone'),
                'description': kwargs.get('message'),
                'type': 'lead',
            }
            
            lead = request.env['crm.lead'].sudo().create(vals)
            
            # Send email notification
            template = request.env.ref('modern_website.contact_form_template')
            if template:
                template.sudo().send_mail(lead.id, force_send=True)
            
            return {
                'success': True,
                'message': 'Thank you for your message. We will get back to you soon.'
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': 'An error occurred while processing your request.'
            }

    @http.route(['/modern_website/load_more'], type='json', auth="public", website=True)
    def load_more_content(self, **kwargs):
        """Handle infinite scroll/load more functionality"""
        offset = int(kwargs.get('offset', 0))
        limit = int(kwargs.get('limit', 10))
        content_type = kwargs.get('content_type', 'blog')
        
        domain = [('website_published', '=', True)]
        
        if content_type == 'blog':
            model = 'blog.post'
        elif content_type == 'products':
            model = 'product.template'
            domain.append(('website_published', '=', True))
        else:
            return {'error': 'Invalid content type'}
            
        records = request.env[model].sudo().search(
            domain,
            limit=limit,
            offset=offset,
            order='create_date desc'
        )
        
        values = {
            'records': records,
            'has_more': len(records) == limit
        }
        
        return request.env['ir.ui.view'].sudo()._render_template(
            f'modern_website.{content_type}_items',
            values
        )

    @http.route(['/modern_website/search'], type='json', auth="public", website=True)
    def search_content(self, **kwargs):
        """Handle ajax search functionality"""
        query = kwargs.get('query', '')
        search_type = kwargs.get('type', 'all')
        limit = int(kwargs.get('limit', 10))
        
        results = {
            'products': [],
            'posts': [],
            'pages': []
        }
        
        if search_type in ['all', 'products']:
            products = request.env['product.template'].sudo().search([
                ('website_published', '=', True),
                '|',
                ('name', 'ilike', query),
                ('description', 'ilike', query)
            ], limit=limit)
            results['products'] = [{
                'id': p.id,
                'name': p.name,
                'url': f'/shop/product/{p.id}',
                'image_url': f'/web/image/product.template/{p.id}/image_128'
            } for p in products]
            
        if search_type in ['all', 'posts']:
            posts = request.env['blog.post'].sudo().search([
                ('website_published', '=', True),
                '|',
                ('name', 'ilike', query),
                ('content', 'ilike', query)
            ], limit=limit)
            results['posts'] = [{
                'id': p.id,
                'name': p.name,
                'url': f'/blog/{p.blog_id.id}/post/{p.id}'
            } for p in posts]
            
        if search_type in ['all', 'pages']:
            pages = request.env['website.page'].sudo().search([
                ('website_published', '=', True),
                '|',
                ('name', 'ilike', query),
                ('arch_db', 'ilike', query)
            ], limit=limit)
            results['pages'] = [{
                'id': p.id,
                'name': p.name,
                'url': p.url
            } for p in pages]
            
        return results