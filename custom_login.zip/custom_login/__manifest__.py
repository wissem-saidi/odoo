# __manifest__.py
{
    'name': 'Modern Website Theme',
    'version': '1.0',
    'category': 'Website',
    'summary': 'Modern and customizable website theme for Odoo 18',
    'sequence': 1,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'depends': ['website', 'web','website_blog','crm','website_sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/assets.xml',
        'views/snippets.xml',
        'views/customize_modal.xml',
        'views/templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'modern_website/static/src/scss/style.scss',
            'modern_website/static/src/js/animation.js',
        ],
    },
    'images': [
        'static/description/banner.png',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}