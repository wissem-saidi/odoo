# __manifest__.py
{
    'name': 'Modern Login Page',
    'version': '1.0',
    'category': 'Website',
    'description': 'A modern, beautiful login page for Odoo 18',
    'author': 'Your Name',
    'depends': ['website', 'auth_signup'],
    'data': [
        'views/login_templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'custom_login_page/static/src/css/custom_style.css',
        ],
    },
    'installable': True,
    'auto_install': False,
}
