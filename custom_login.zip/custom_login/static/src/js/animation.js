// static/src/js/animation.js
odoo.define('modern_website.animation', function (require) {
    'use strict';

    var publicWidget = require('web.public.widget');
    var Animation = require('website.content.snippets.animation');

    publicWidget.registry.ModernAnimation = Animation.extend({
        selector: '.fade-in',
        
        start: function () {
            this._super.apply(this, arguments);
            this._onScroll = _.throttle(this._onScroll.bind(this), 50);
            window.addEventListener('scroll', this._onScroll);
            this._onScroll();
        },
        
        destroy: function () {
            window.removeEventListener('scroll', this._onScroll);
            this._super.apply(this, arguments);
        },
        
        _onScroll: function () {
            var elements = document.querySelectorAll('.fade-in:not(.visible)');
            
            elements.forEach(function (element) {
                var position = element.getBoundingClientRect();
                
                if (position.top < window.innerHeight - 100) {
                    element.classList.add('visible');
                }
            });
        },
    });
    
    return publicWidget.registry.ModernAnimation;
});