# models/theme_config.py
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class ThemeConfiguration(models.Model):
    _name = 'modern.theme.config'
    _description = 'Modern Theme Configuration'

    name = fields.Char(required=True)
    website_id = fields.Many2one('website', string='Website', required=True)
    primary_color = fields.Char(string='Primary Color', default='#2C3E50')
    secondary_color = fields.Char(string='Secondary Color', default='#3498DB')
    accent_color = fields.Char(string='Accent Color', default='#E74C3C')
    font_family = fields.Selection([
        ('roboto', 'Roboto'),
        ('open-sans', 'Open Sans'),
        ('lato', 'Lato'),
        ('montserrat', 'Montserrat'),
        ('custom', 'Custom')
    ], string='Font Family', default='roboto')
    custom_font_url = fields.Char(string='Custom Font URL')
    is_active = fields.Boolean(default=False)
    
    header_style = fields.Selection([
        ('standard', 'Standard'),
        ('centered', 'Centered'),
        ('minimal', 'Minimal'),
        ('full-width', 'Full Width')
    ], string='Header Style', default='standard')
    
    footer_columns = fields.Integer(string='Footer Columns', default=3)
    enable_animations = fields.Boolean(string='Enable Animations', default=True)
    
    @api.constrains('footer_columns')
    def _check_footer_columns(self):
        for record in self:
            if record.footer_columns < 1 or record.footer_columns > 4:
                raise ValidationError('Footer columns must be between 1 and 4')

    def apply_theme(self):
        self.ensure_one()
        if self.is_active:
            return
        
        # Deactivate other themes for this website
        self.search([
            ('website_id', '=', self.website_id.id),
            ('id', '!=', self.id)
        ]).write({'is_active': False})
        
        self.is_active = True
        self.website_id.theme_id = self.id


# models/custom_section.py
class CustomSection(models.Model):
    _name = 'modern.website.section'
    _description = 'Custom Website Section'
    _order = 'sequence, id'

    name = fields.Char(required=True)
    sequence = fields.Integer(default=10)
    section_type = fields.Selection([
        ('banner', 'Banner'),
        ('features', 'Features'),
        ('gallery', 'Gallery'),
        ('testimonials', 'Testimonials'),
        ('cta', 'Call to Action'),
        ('custom', 'Custom')
    ], required=True)
    
    content = fields.Html(string='Content', sanitize=True)
    css_class = fields.Char(string='CSS Class')
    background_type = fields.Selection([
        ('color', 'Color'),
        ('image', 'Image'),
        ('video', 'Video')
    ], default='color')
    background_color = fields.Char(default='#FFFFFF')
    background_image = fields.Binary('Background Image')
    background_video_url = fields.Char('Background Video URL')
    
    is_published = fields.Boolean(default=True)
    website_id = fields.Many2one('website', string='Website')


# models/layout_preset.py
class LayoutPreset(models.Model):
    _name = 'modern.layout.preset'
    _description = 'Layout Preset'

    name = fields.Char(required=True)
    description = fields.Text()
    layout_type = fields.Selection([
        ('landing', 'Landing Page'),
        ('blog', 'Blog'),
        ('shop', 'Shop'),
        ('portfolio', 'Portfolio'),
        ('custom', 'Custom')
    ], required=True)
    
    content_structure = fields.Text(string='Content Structure')
    css_framework = fields.Selection([
        ('bootstrap', 'Bootstrap'),
        ('tailwind', 'Tailwind'),
        ('custom', 'Custom')
    ], default='bootstrap')
    
    header_included = fields.Boolean(default=True)
    footer_included = fields.Boolean(default=True)
    sidebar_position = fields.Selection([
        ('none', 'None'),
        ('left', 'Left'),
        ('right', 'Right')
    ], default='none')
    
    is_responsive = fields.Boolean(default=True)
    preview_image = fields.Binary('Preview Image')


# models/custom_component.py
class CustomComponent(models.Model):
    _name = 'modern.custom.component'
    _description = 'Custom Component'

    name = fields.Char(required=True)
    component_type = fields.Selection([
        ('header', 'Header'),
        ('footer', 'Footer'),
        ('sidebar', 'Sidebar'),
        ('card', 'Card'),
        ('button', 'Button'),
        ('form', 'Form'),
        ('custom', 'Custom')
    ], required=True)
    
    html_content = fields.Html(string='HTML Content', sanitize=True)
    css_content = fields.Text(string='CSS Content')
    js_content = fields.Text(string='JavaScript Content')
    
    is_reusable = fields.Boolean(default=True)
    is_public = fields.Boolean(default=True)
    website_ids = fields.Many2many('website', string='Websites')
    
    @api.constrains('html_content')
    def _check_html_content(self):
        for record in self:
            if record.html_content and '<script' in record.html_content:
                raise ValidationError('Direct script tags are not allowed in HTML content')


# models/animation_preset.py
class AnimationPreset(models.Model):
    _name = 'modern.animation.preset'
    _description = 'Animation Preset'

    name = fields.Char(required=True)
    animation_type = fields.Selection([
        ('fade', 'Fade'),
        ('slide', 'Slide'),
        ('zoom', 'Zoom'),
        ('rotate', 'Rotate'),
        ('custom', 'Custom')
    ], required=True)
    
    duration = fields.Float(string='Duration (s)', default=0.3)
    delay = fields.Float(string='Delay (s)', default=0)
    timing_function = fields.Selection([
        ('ease', 'Ease'),
        ('linear', 'Linear'),
        ('ease-in', 'Ease In'),
        ('ease-out', 'Ease Out'),
        ('ease-in-out', 'Ease In Out')
    ], default='ease')
    
    css_classes = fields.Char(string='CSS Classes')
    custom_css = fields.Text(string='Custom CSS')
    
    @api.constrains('duration', 'delay')
    def _check_timing_values(self):
        for record in self:
            if record.duration <= 0:
                raise ValidationError('Duration must be greater than 0')
            if record.delay < 0:
                raise ValidationError('Delay cannot be negative')